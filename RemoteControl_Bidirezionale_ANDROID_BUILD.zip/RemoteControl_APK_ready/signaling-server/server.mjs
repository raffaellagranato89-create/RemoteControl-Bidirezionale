import { WebSocketServer } from 'ws';
import crypto from 'node:crypto';

const port = Number(process.env.PORT || 8787);
const wss = new WebSocketServer({ port });
const rooms = new Map();
const TTL = 10 * 60 * 1000;
const RELAY_TYPES = new Set(['signal']);

function send(ws, message) { if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(message)); }
function cleanup() {
  const now = Date.now();
  for (const [code, room] of rooms) if (room.expires < now || room.clients.size === 0) rooms.delete(code);
}
setInterval(cleanup, 30_000).unref();

wss.on('connection', ws => {
  ws.id = crypto.randomUUID();
  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws, {type:'error', code:'BAD_JSON'}); }
    if (msg.type === 'join') {
      const code = String(msg.code || '');
      if (!/^\d{6}$/.test(code)) return send(ws, {type:'error', code:'BAD_CODE'});
      let room = rooms.get(code);
      if (!room) rooms.set(code, room = {clients:new Set(), expires:Date.now()+TTL});
      if (room.clients.size >= 2) return send(ws, {type:'error', code:'ROOM_FULL'});
      room.clients.add(ws); ws.room = room; ws.code = code; ws.deviceId = String(msg.deviceId || crypto.randomUUID());
      send(ws, {type:'joined', peerCount: room.clients.size, expiresAt: room.expires});
      for (const peer of room.clients) if (peer !== ws) { send(peer, {type:'peer-joined', deviceId: ws.deviceId}); send(ws, {type:'peer-present', deviceId: peer.deviceId}); }
      return;
    }
    if (RELAY_TYPES.has(msg.type) && ws.room && typeof msg === 'object') {
      for (const peer of ws.room.clients) if (peer !== ws) send(peer, msg);
      return;
    }
    if (msg.type === 'leave') ws.close();
  });
  ws.on('close', () => {
    if (!ws.room) return;
    ws.room.clients.delete(ws);
    for (const peer of ws.room.clients) send(peer, {type:'peer-left'});
  });
});
console.log(`Signaling server listening on ws://0.0.0.0:${port}`);
