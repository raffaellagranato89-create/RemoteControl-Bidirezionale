#if canImport(WebRTC)
import Foundation
import Combine
import WebRTC

/// WebRTC DataChannel adapter. Add the WebRTC framework/package to the iOS target,
/// then feed signaling messages from SignalingClient.onMessage into handleSignal().
final class WebRTCFileChannel: NSObject, ObservableObject, RTCDataChannelDelegate, RTCPeerConnectionDelegate {
    private let factory: RTCPeerConnectionFactory
    private var peer: RTCPeerConnection?
    private var channel: RTCDataChannel?
    private let onStatus: (String) -> Void
    @Published var remoteVideoTrack: RTCVideoTrack?
    var onIceCandidate: ((RTCIceCandidate) -> Void)?

    init(onStatus: @escaping (String) -> Void) {
        self.onStatus = onStatus
        RTCInitializeSSL()
        self.factory = RTCPeerConnectionFactory(encoderFactory: RTCDefaultVideoEncoderFactory(), decoderFactory: RTCDefaultVideoDecoderFactory())
        super.init()
    }

    func makeOffer(sendSignal: @escaping ([String: Any]) -> Void) {
        ensurePeer(sendSignal: sendSignal)
        let constraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)
        peer?.offer(for: constraints) { [weak self] sdp, error in
            guard let self, let sdp else { self?.onStatus(error?.localizedDescription ?? "Offer WebRTC non riuscito"); return }
            self.peer?.setLocalDescription(sdp) { error in
                if let error { self.onStatus(error.localizedDescription); return }
                sendSignal(["kind":"offer", "sdp":sdp.sdp])
            }
        }
    }

    func handleSignal(_ data: [String: Any], sendSignal: @escaping ([String: Any]) -> Void) {
        ensurePeer(sendSignal: sendSignal)
        guard let kind = data["kind"] as? String else { return }
        switch kind {
        case "offer":
            let desc = RTCSessionDescription(type: .offer, sdp: data["sdp"] as? String ?? "")
            peer?.setRemoteDescription(desc) { [weak self] error in
                guard let self else { return }
                if let error { self.onStatus(error.localizedDescription); return }
                let constraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)
                self.peer?.answer(for: constraints) { answer, error in
                    guard let answer else { self.onStatus(error?.localizedDescription ?? "Answer WebRTC non riuscito"); return }
                    self.peer?.setLocalDescription(answer) { error in
                        if let error { self.onStatus(error.localizedDescription); return }
                        sendSignal(["kind":"answer", "sdp":answer.sdp])
                    }
                }
            }
        case "answer":
            peer?.setRemoteDescription(RTCSessionDescription(type: .answer, sdp: data["sdp"] as? String ?? "")) { [weak self] error in
                if let error { self?.onStatus(error.localizedDescription) }
            }
        case "ice":
            if let candidate = data["candidate"] as? String {
                let c = RTCIceCandidate(sdp: candidate, sdpMLineIndex: Int32(data["sdpMLineIndex"] as? Int ?? 0), sdpMid: data["sdpMid"] as? String)
                peer?.add(c)
            }
        default: break
        }
    }

    private func ensurePeer(sendSignal: @escaping ([String: Any]) -> Void) {
        if peer != nil { return }
        let config = RTCConfiguration()
        config.iceServers = [RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"])]
        let constraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)
        peer = factory.peerConnection(with: config, constraints: constraints, delegate: self)
    }

    func peerConnection(_ peerConnection: RTCPeerConnection, didOpen dataChannel: RTCDataChannel) { channel = dataChannel; dataChannel.delegate = self; onStatus("WebRTC DataChannel aperto") }
    func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) { onIceCandidate?(candidate) }
    func dataChannelDidChangeState(_ dataChannel: RTCDataChannel) { onStatus("DataChannel: \\(dataChannel.readyState.rawValue)") }
    func dataChannel(_ dataChannel: RTCDataChannel, didReceiveMessageWith buffer: RTCDataBuffer) { onStatus("Dati ricevuti: \\(buffer.data.count) byte") }

    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) {
        if let track = stream.videoTracks.first { DispatchQueue.main.async { self.remoteVideoTrack = track } }
    }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) {}
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) { onStatus("ICE: \\(newState.rawValue)") }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCPeerConnectionState) { onStatus("PeerConnection: \\(stateChanged.rawValue)") }
    func peerConnection(_ peerConnection: RTCPeerConnection, didStartReceivingOn transceiver: RTCRtpTransceiver) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd rtpReceiver: RTCRtpReceiver, streams: [RTCMediaStream]) {
        if let track = rtpReceiver.track as? RTCVideoTrack { DispatchQueue.main.async { self.remoteVideoTrack = track } }
    }
}
#endif
