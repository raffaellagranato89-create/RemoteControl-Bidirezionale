import SwiftUI
import UniformTypeIdentifiers
#if canImport(WebRTC)
import WebRTC
#endif

@main
struct RemoteControlApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

struct ContentView: View {
    @State private var pairingCode = ""
    @State private var connected = false
    @State private var showImporter = false
    @State private var incoming: IncomingFile?
    @StateObject private var signaling = SignalingClient()
    #if canImport(WebRTC)
    @StateObject private var rtc = WebRTCFileChannel(onStatus: { _ in })
    #endif

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                #if canImport(WebRTC)
                if let track = rtc.remoteVideoTrack {
                    WebRTCVideoView(track: track)
                        .frame(maxWidth: .infinity, minHeight: 260, maxHeight: 420)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                } else {
                    RoundedRectangle(cornerRadius: 12).fill(.black.opacity(0.9))
                        .overlay(Text("Nessun video remoto").foregroundStyle(.white))
                        .frame(height: 260)
                }
                #endif

                Form {
                    Section("Associazione") {
                        TextField("Codice a 6 cifre", text: $pairingCode)
                            .keyboardType(.numberPad)
                            .textContentType(.oneTimeCode)
                        Button(connected ? "Disconnetti" : "Collega dispositivo") {
                            if connected { signaling.disconnect(); connected = false }
                            else { signaling.connect(code: pairingCode, serverURL: "ws://127.0.0.1:8787"); connected = true }
                        }
                        .disabled(pairingCode.count != 6)
                    }
                    Section("Scambio file") {
                        Button { showImporter = true } label: { Label("Invia file", systemImage: "arrow.up.doc") }
                            .disabled(!connected)
                    }
                    Section("Stato") {
                        Label(connected ? signaling.status : "Nessuna sessione", systemImage: connected ? "checkmark.circle" : "circle")
                    }
                }
                .frame(maxHeight: 330)
            }
            .padding(.top, 8)
            .navigationTitle("Remote Control")
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first {
                    // File transport remains consent-based; the WebRTC channel is the data path in the target.
                    #if canImport(WebRTC)
                    _ = url
                    #endif
                }
            }
            .alert("File in arrivo", isPresented: Binding(get: { incoming != nil }, set: { if !$0 { incoming = nil } })) {
                Button("Ricevi") { incoming = nil }
                Button("Rifiuta", role: .cancel) { incoming = nil }
            } message: { Text(incoming.map { "\($0.name)\n\($0.size) byte" } ?? "") }
            .onAppear {
                #if canImport(WebRTC)
                rtc.onIceCandidate = { candidate in
                    signaling.sendSignal(["kind":"ice", "candidate":candidate.sdp, "sdpMLineIndex":Int(candidate.sdpMLineIndex), "sdpMid":candidate.sdpMid ?? ""]) }
                #endif
                signaling.onMessage = { message in
                    if let data = message["data"] as? [String: Any] {
                        #if canImport(WebRTC)
                        rtc.handleSignal(data) { signal in signaling.sendSignal(signal) }
                        #endif
                        if let kind = data["kind"] as? String, kind == "file_offer", let id = data["id"] as? String, let name = data["name"] as? String {
                            let size = data["size"] as? Int ?? 0
                            incoming = IncomingFile(id: id, name: name, size: size)
                        }
                    }
                }
            }
        }
    }
}

struct IncomingFile: Identifiable { let id: String; let name: String; let size: Int }

#if canImport(WebRTC)
struct WebRTCVideoView: UIViewRepresentable {
    let track: RTCVideoTrack
    func makeUIView(context: Context) -> RTCMTLVideoView {
        let view = RTCMTLVideoView(frame: .zero)
        view.videoContentMode = .scaleAspectFit
        track.add(view)
        return view
    }
    func updateUIView(_ uiView: RTCMTLVideoView, context: Context) {}
    static func dismantleUIView(_ uiView: RTCMTLVideoView, coordinator: ()) { }
}
#endif
