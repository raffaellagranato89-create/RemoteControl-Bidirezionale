# iOS Remote Control

Client SwiftUI con pairing a 6 cifre e signaling WebSocket.

## WebRTC DataChannel
`WebRTCFileChannel.swift` contiene l'adapter per il trasferimento file via RTCDataChannel. Nel target Xcode va aggiunto il framework WebRTC (tramite il package/SDK WebRTC scelto dal progetto), quindi collegato a `SignalingClient.onMessage`:

- `signal.kind=offer|answer|ice` -> `handleSignal(...)`
- il dispositivo che ha l'ID più piccolo può creare l'offer;
- i chunk binari dei file vanno sul DataChannel, non sul relay WebSocket;
- l'offerta del file resta sul signaling e richiede accettazione prima dell'invio.

Per produzione usare sempre `wss://` e autenticazione forte della sessione.
