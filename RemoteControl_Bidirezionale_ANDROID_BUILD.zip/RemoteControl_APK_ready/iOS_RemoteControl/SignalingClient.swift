import Foundation
import Combine

final class SignalingClient: NSObject, ObservableObject, URLSessionWebSocketDelegate {
    @Published var status = "Non connesso"
    private var socket: URLSessionWebSocketTask?
    private var session: URLSession!
    private let deviceId = UUID().uuidString
    var onMessage: (([String: Any]) -> Void)?

    override init() {
        super.init()
        session = URLSession(configuration: .default, delegate: self, delegateQueue: OperationQueue.main)
    }

    func connect(code: String, serverURL: String) {
        guard let url = URL(string: serverURL) else { status = "URL non valido"; return }
        socket = session.webSocketTask(with: url)
        socket?.resume()
        send(["type":"join", "code":code, "deviceId":deviceId])
        status = "Connessione…"
        receiveLoop()
    }

    func send(_ object: [String: Any]) {
        guard JSONSerialization.isValidJSONObject(object), let data = try? JSONSerialization.data(withJSONObject: object), let text = String(data: data, encoding: .utf8) else { return }
        socket?.send(.string(text)) { [weak self] error in
            if let error { DispatchQueue.main.async { self?.status = "Errore: \(error.localizedDescription)" } }
        }
    }

    func sendSignal(_ data: [String: Any]) { send(["type":"signal", "data":data]) }

    func disconnect() { socket?.cancel(with: .normalClosure, reason: nil); socket = nil; status = "Disconnesso" }

    private func receiveLoop() {
        socket?.receive { [weak self] result in
            guard let self else { return }
            switch result {
            case .failure(let error): DispatchQueue.main.async { self.status = "Errore: \(error.localizedDescription)" }
            case .success(let message):
                if case .string(let text) = message, let data = text.data(using: .utf8), let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    DispatchQueue.main.async {
                        switch object["type"] as? String {
                        case "joined": self.status = "Dispositivo associato"
                        case "peer-left": self.status = "Altro dispositivo disconnesso"
                        case "peer-joined", "peer-present": self.status = "Altro dispositivo collegato"
                        default: break
                        }
                        self.onMessage?(object)
                    }
                }
                self.receiveLoop()
            }
        }
    }

    func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask, didOpenWithProtocol protocol: String?) { status = "Connesso" }
    func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask, didCloseWith closeCode: URLSessionWebSocket.CloseCode, reason: Data?) { status = "Disconnesso" }
}
