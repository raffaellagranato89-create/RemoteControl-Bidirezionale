plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.remotecontrol"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.remotecontrol"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.1"
    }
}


dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.webrtc:google-webrtc:1.0.32006")
}
