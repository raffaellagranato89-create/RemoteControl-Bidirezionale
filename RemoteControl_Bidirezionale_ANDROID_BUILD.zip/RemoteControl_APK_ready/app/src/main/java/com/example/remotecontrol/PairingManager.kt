package com.example.remotecontrol

import android.content.Context
import java.security.SecureRandom

object PairingManager {
    private const val PREFS = "pairing"
    private const val CODE = "code"
    private const val SESSION = "session"
    private const val DEVICE = "device_id"
    private val random = SecureRandom()

    fun currentCode(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(CODE, null) ?: newCode(context)
    }

    fun newCode(context: Context): String {
        val code = (100000 + random.nextInt(900000)).toString()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(CODE, code).apply()
        return code
    }


    fun deviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(DEVICE, null) ?: java.util.UUID.randomUUID().toString().also {
            prefs.edit().putString(DEVICE, it).apply()
        }
    }

    fun startSession(context: Context): String {
        val token = buildString {
            repeat(32) { append("0123456789abcdef"[random.nextInt(16)]) }
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(SESSION, token).apply()
        return token
    }

    fun clearSession(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(SESSION).apply()
    }
}
