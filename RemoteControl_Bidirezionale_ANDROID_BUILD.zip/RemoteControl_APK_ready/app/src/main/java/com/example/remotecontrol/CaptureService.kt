package com.example.remotecontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/** Keeps the user-visible foreground service alive while MediaProjection is active. */
class CaptureService : Service() {
    companion object { private const val CHANNEL_ID = "remote_capture"; private const val NOTIFICATION_ID = 10 }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Remote Control", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Condivisione schermo attiva")
                .setContentText("La sessione remota è attiva. Puoi terminarla dall'app.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("Condivisione schermo attiva")
                .setContentText("La sessione remota è attiva. Puoi terminarla dall'app.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
        startForeground(NOTIFICATION_ID, notification)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        PairingManager.clearSession(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
