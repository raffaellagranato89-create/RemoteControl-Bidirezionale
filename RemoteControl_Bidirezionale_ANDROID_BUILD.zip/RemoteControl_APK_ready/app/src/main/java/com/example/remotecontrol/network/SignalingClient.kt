package com.example.remotecontrol.network

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.Executors

/**
 * WebSocket session client. The same authenticated room carries
 * signaling and consented, chunked file-transfer messages.
 */
class SignalingClient(
    private val serverUrl: String,
    private val deviceId: String = java.util.UUID.randomUUID().toString(),
    private val onEvent: (String, JSONObject?) -> Unit
) {
    private val executor = Executors.newSingleThreadExecutor()
    private var socket: WebSocket? = null
    private val main = Handler(Looper.getMainLooper())

    fun connect(code: String) {
        executor.execute {
            val request = Request.Builder().url(serverUrl).build()
            OkHttpClient().newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                    socket = webSocket
                    send(JSONObject().put("type", "join").put("code", code).put("deviceId", deviceId))
                    main.post { onEvent("open", null) }
                }
                override fun onMessage(webSocket: WebSocket, text: String) {
                    val json = runCatching { JSONObject(text) }.getOrNull()
                    if (json != null) main.post { onEvent(json.optString("type"), json) }
                }
                override fun onMessage(webSocket: WebSocket, bytes: ByteString) = Unit
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                    main.post { onEvent("error", JSONObject().put("message", t.message ?: "WebSocket error")) }
                }
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    main.post { onEvent("closed", null) }
                }
            })
        }
    }

    fun sendJson(message: JSONObject) { socket?.send(message.toString()) }
    fun send(message: JSONObject) = sendJson(message)
    fun close() { socket?.close(1000, "bye"); socket = null }
}
