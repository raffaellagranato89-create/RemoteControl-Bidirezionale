package com.example.remotecontrol

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup
import android.view.MotionEvent
import android.provider.Settings
import org.webrtc.EglBase
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import com.example.remotecontrol.network.SignalingClient
import org.json.JSONObject

class MainActivity : Activity() {
    private val captureRequest = 1001
    private val fileRequest = 2001
    private lateinit var codeView: TextView
    private lateinit var statusView: TextView
    private lateinit var sessionManager: SessionManager
    private lateinit var signaling: SignalingClient
    private lateinit var rtcFiles: WebRtcDataChannelManager
    private val localDeviceId by lazy { PairingManager.deviceId(this) }
    private var connected = false
    private lateinit var videoRenderer: SurfaceViewRenderer
    private var eglBase: EglBase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionManager = SessionManager(this) { runOnUiThread { statusView.text = "Stato: $it" } }
        signaling = SignalingClient("ws://10.0.2.2:8787", localDeviceId) { event, json ->
            runOnUiThread {
                when (event) {
                    "joined" -> { connected = true; statusView.text = "Stato: dispositivo associato" }
                    "peer-joined", "peer-present" -> {
                        val remoteId = json?.optString("deviceId", "") ?: ""
                        statusView.text = "Stato: altro dispositivo collegato"
                        if (remoteId.isNotBlank() && localDeviceId < remoteId) rtcFiles.createOffer()
                    }
                    "peer-left" -> statusView.text = "Stato: altro dispositivo disconnesso"
                    "signal" -> json?.optJSONObject("data")?.let { rtcFiles.onSignal(it) }
                    "error" -> statusView.text = "Errore: ${json?.optString("message", json.optString("code"))}"
                    "closed" -> { connected = false; statusView.text = "Stato: disconnesso" }
                }
            }
        }
        rtcFiles = WebRtcDataChannelManager(this, signaling, object : WebRtcDataChannelManager.Callback {
            override fun onState(text: String) { runOnUiThread { statusView.text = "Stato: $text" } }
            override fun onProgress(percent: Int, label: String) { runOnUiThread { statusView.text = "Stato: $label — $percent%" } }
            override fun onIncoming(id: String, name: String, size: Long) {
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity).setTitle("File in arrivo")
                        .setMessage("$name\n${size / 1024} KB\n\nVuoi riceverlo?")
                        .setPositiveButton("Ricevi") { _, _ -> rtcFiles.accept(id) }
                        .setNegativeButton("Rifiuta") { _, _ -> rtcFiles.reject(id) }.show()
                }
            }
            override fun onCompleted(label: String) { runOnUiThread { statusView.text = "Stato: $label" } }
            override fun onError(message: String) { runOnUiThread { statusView.text = "Errore: $message" } }
            override fun onRemoteVideo(track: VideoTrack) { runOnUiThread { track.addSink(videoRenderer); statusView.text = "Stato: video remoto ricevuto" } }
            override fun onRemoteControlRequest() { runOnUiThread { statusView.text = "Controllo remoto richiesto" } }
        })
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        val container = FrameLayout(this)
        container.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 520)
        eglBase = EglBase.create()
        videoRenderer = SurfaceViewRenderer(this)
        videoRenderer.init(eglBase!!.eglBaseContext, null)
        videoRenderer.setEnableHardwareScaler(true)
        videoRenderer.setMirror(false)
        var downX = 0f
        var downY = 0f
        videoRenderer.setOnTouchListener { _, event ->
            if (!RemoteControlPreferences.enabled(this)) return@setOnTouchListener false
            val w = videoRenderer.width.coerceAtLeast(1).toFloat()
            val h = videoRenderer.height.coerceAtLeast(1).toFloat()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val x = event.x / w * 1280f; val y = event.y / h * 720f
                    val sx = downX / w * 1280f; val sy = downY / h * 720f
                    if (kotlin.math.hypot(x - sx, y - sy) < 24f) rtcFiles.sendInput("tap", x, y)
                    else rtcFiles.sendInput("swipe", sx, sy, x, y)
                    true
                }
                else -> true
            }
        }
        container.addView(videoRenderer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(container)
        root.addView(TextView(this).apply { text = "Remote Control bidirezionale"; textSize = 24f })
        root.addView(TextView(this).apply { text = "Associazione autorizzata e scambio file tra dispositivi abbinati."; textSize = 16f; setPadding(0,16,0,24) })
        root.addView(TextView(this).apply { text = "Codice di associazione"; textSize = 15f })
        codeView = TextView(this).apply { text = PairingManager.currentCode(this@MainActivity); textSize = 36f; setPadding(0,8,0,8) }
        root.addView(codeView)
        val pairingButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pairingButtons.addView(Button(this).apply { text = "Nuovo codice"; setOnClickListener { codeView.text = PairingManager.newCode(this@MainActivity) } })
        pairingButtons.addView(Button(this).apply { text = "Copia"; setOnClickListener { copyCode() } })
        root.addView(pairingButtons)
        statusView = TextView(this).apply { text = "Stato: nessuna sessione"; setPadding(0,24,0,16) }
        root.addView(statusView)
        root.addView(Button(this).apply { text = "Collega dispositivo"; setOnClickListener { signaling.connect(codeView.text.toString()) } })
        root.addView(Button(this).apply { text = "Invia file"; setOnClickListener { if (!connected) Toast.makeText(this@MainActivity,"Collega prima un dispositivo",Toast.LENGTH_SHORT).show() else startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), fileRequest) } })
        root.addView(Button(this).apply { text = "Avvia condivisione schermo"; setOnClickListener { requestScreenCapture() } })
        root.addView(Button(this).apply {
            text = if (RemoteControlPreferences.enabled(this@MainActivity)) "Controllo remoto: ATTIVO" else "Controllo remoto: DISATTIVO"
            setOnClickListener {
                val next = !RemoteControlPreferences.enabled(this@MainActivity)
                RemoteControlPreferences.setEnabled(this@MainActivity, next)
                text = if (next) "Controllo remoto: ATTIVO" else "Controllo remoto: DISATTIVO"
                if (next && !RemoteInputService.isRunning()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        root.addView(Button(this).apply { text = "Richiedi controllo remoto"; setOnClickListener { rtcFiles.requestRemoteControl() } })
        val keyboard = EditText(this).apply { hint = "Testo da inserire sul dispositivo remoto" }
        root.addView(keyboard)
        root.addView(Button(this).apply { text = "Invia testo"; setOnClickListener { if (keyboard.text.isNotEmpty()) rtcFiles.sendInput("type", text = keyboard.text.toString()) } })
        root.addView(Button(this).apply { text = "Apri impostazioni Accessibilità"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "Indietro remoto"; setOnClickListener { rtcFiles.sendInput("back") } })
        root.addView(Button(this).apply { text = "Home remoto"; setOnClickListener { rtcFiles.sendInput("home") } })
        root.addView(Button(this).apply { text = "Termina sessione"; setOnClickListener { stopCapture() } })
        root.addView(TextView(this).apply { text = "I file vengono trasferiti solo nella sessione associata. Il destinatario deve accettare ogni trasferimento."; textSize = 13f; setPadding(0,24,0,0) })
        setContentView(root)
    }

    private fun copyCode() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Codice pairing", codeView.text))
        Toast.makeText(this, "Codice copiato", Toast.LENGTH_SHORT).show()
    }
    private fun requestScreenCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
    }
    private fun stopCapture() {
        signaling.close(); rtcFiles.close(); sessionManager.close(); stopService(Intent(this, CaptureService::class.java)); PairingManager.clearSession(this)
        statusView.text = "Stato: sessione terminata"; connected = false
    }

    override fun onDestroy() {
        runCatching { videoRenderer.release() }
        eglBase?.release()
        rtcFiles.close()
        signaling.close()
        super.onDestroy()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest && resultCode == RESULT_OK) data?.data?.let { rtcFiles.send(it) }
        if (requestCode == captureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                PairingManager.startSession(this)
                startForegroundService(Intent(this, CaptureService::class.java))
                rtcFiles.startScreenCapture(resultCode, data)
                rtcFiles.createOffer()
                statusView.text = "Stato: condivisione schermo attiva"
            } else statusView.text = "Stato: autorizzazione annullata"
        }
    }
}
