package com.example.remotecontrol

import android.content.Context
import com.example.remotecontrol.network.SignalingClient
import org.json.JSONObject

/** Coordinates an explicitly paired signaling session. */
class SessionManager(private val context: Context, private val onState: (String) -> Unit) {
    private var client: SignalingClient? = null

    fun connect(code: String, signalingUrl: String) {
        client?.close()
        client = SignalingClient(signalingUrl) { event, payload ->
            when (event) {
                "open" -> onState("Server di segnalazione connesso")
                "joined" -> onState("Dispositivo associato (${payload?.optInt("peerCount", 1) ?: 1}/2)")
                "peer-joined" -> onState("Dispositivo remoto connesso")
                "peer-left" -> onState("Dispositivo remoto disconnesso")
                "signal" -> onState("Segnale WebRTC ricevuto")
                "error" -> onState("Errore: ${payload?.optString("message", "connessione")}")
                "closed" -> onState("Sessione chiusa")
            }
        }
        client?.connect(code)
    }

    fun sendSignal(data: JSONObject) {
        client?.send(JSONObject().put("type", "signal").put("data", data))
    }

    fun close() {
        client?.close()
        client = null
        onState("Sessione terminata")
    }
}
