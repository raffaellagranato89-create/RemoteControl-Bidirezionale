package com.example.remotecontrol

import android.content.Context
import android.net.Uri
import com.example.remotecontrol.network.SignalingClient
import org.json.JSONObject
import org.webrtc.*
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * WebRTC DataChannel transport for consented file exchange.
 * Signaling still travels through the paired WebSocket room; file bytes do not.
 */
class WebRtcDataChannelManager(
    private val context: Context,
    private val signaling: SignalingClient,
    private val callback: Callback
) {
    interface Callback {
        fun onState(text: String)
        fun onProgress(percent: Int, label: String)
        fun onIncoming(id: String, name: String, size: Long)
        fun onCompleted(label: String)
        fun onError(message: String)
        fun onRemoteVideo(track: VideoTrack)
        fun onRemoteControlRequest()
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val factory: PeerConnectionFactory
    private var peer: PeerConnection? = null
    private var channel: DataChannel? = null
    private var eglBase: EglBase? = null
    private var screenCapturer: VideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var screenStarted = false
    private var pendingSend: PendingSend? = null
    private var offeredSend: PendingSend? = null
    private val incoming = mutableMapOf<String, Incoming>()
    private data class PendingSend(val id: String, val uri: Uri, val name: String, val size: Long)
    private data class Incoming(val name: String, val size: Long, val out: ByteArrayOutputStream = ByteArrayOutputStream())

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    fun createOffer() {
        ensurePeer(true)
        localVideoTrack?.let { track -> if (peer != null) { /* track is already attached when capture started */ } }
        peer?.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                peer?.setLocalDescription(SdpObserverAdapter(), desc)
                signaling.sendJson(JSONObject().put("type", "signal").put("data", JSONObject()
                    .put("kind", "offer").put("sdp", desc.description)))
            }
        }, MediaConstraints())
    }

    fun onSignal(data: JSONObject) {
        when (data.optString("kind")) {
            "offer" -> {
                ensurePeer(false)
                val desc = SessionDescription(SessionDescription.Type.OFFER, data.optString("sdp"))
                peer?.setRemoteDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        peer?.createAnswer(object : SdpObserverAdapter() {
                            override fun onCreateSuccess(answer: SessionDescription) {
                                peer?.setLocalDescription(SdpObserverAdapter(), answer)
                                signaling.sendJson(JSONObject().put("type", "signal").put("data", JSONObject()
                                    .put("kind", "answer").put("sdp", answer.description)))
                            }
                        }, MediaConstraints())
                    }
                }, desc)
            }
            "answer" -> peer?.setRemoteDescription(SdpObserverAdapter(), SessionDescription(SessionDescription.Type.ANSWER, data.optString("sdp")))
            "ice" -> {
                peer?.addIceCandidate(IceCandidate(data.optString("sdpMid"), data.optInt("sdpMLineIndex"), data.optString("candidate")))
            }
        }
    }

    private fun ensurePeer(offerer: Boolean) {
        if (peer != null) return
        val rtcConfig = PeerConnection.RTCConfiguration(listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        ))
        peer = factory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                signaling.sendJson(JSONObject().put("type", "signal").put("data", JSONObject()
                    .put("kind", "ice").put("candidate", c.sdp)
                    .put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)))
            }
            override fun onDataChannel(dc: DataChannel) { attachChannel(dc) }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) { callback.onState("WebRTC: ${newState.name}") }
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) = Unit
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState) = Unit
            override fun onSignalingChange(newState: PeerConnection.SignalingState) = Unit
            override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) = Unit
            override fun onAddStream(stream: MediaStream) = Unit
            override fun onRemoveStream(stream: MediaStream) = Unit
            override fun onRenegotiationNeeded() = Unit
            override fun onAddTrack(receiver: RtpReceiver, mediaStreams: Array<out MediaStream>) {
                (receiver.track() as? VideoTrack)?.let { callback.onRemoteVideo(it) }
            }
        })
        if (offerer) attachChannel(peer!!.createDataChannel("files", DataChannel.Init()))
    }

    private fun attachChannel(dc: DataChannel) {
        channel = dc
        dc.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previousAmount: Long) = Unit
            override fun onStateChange() {
                callback.onState("File DataChannel: ${dc.state()}")
                if (dc.state() == DataChannel.State.OPEN) pendingSend?.let { p -> pendingSend = null; sendFileInternal(p) }
            }
            override fun onMessage(buffer: DataChannel.Buffer) { if (!buffer.binary) handleText(String(buffer.data.array(), Charsets.UTF_8)) else handleBinary(buffer.data) }
        })
    }

    fun startScreenCapture(resultCode: Int, data: android.content.Intent) {
        try {
            if (screenStarted) return
            if (eglBase == null) eglBase = EglBase.create()
            val capturer = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
                override fun onStop() { callback.onState("Condivisione schermo terminata") }
            })
            screenCapturer = capturer
            videoSource = factory.createVideoSource(false)
            capturer.initialize(SurfaceTextureHelper.create("ScreenCapture", eglBase!!.eglBaseContext), context, videoSource!!.capturerObserver)
            capturer.startCapture(1280, 720, 30)
            localVideoTrack = factory.createVideoTrack("screen", videoSource)
            screenStarted = true
            if (peer != null) {
                peer?.addTrack(localVideoTrack, listOf("screen"))
            }
            callback.onState("Condivisione schermo pronta")
        } catch (e: Exception) {
            callback.onError("Avvio cattura schermo: ${e.message ?: "errore"}")
        }
    }

    fun send(uri: Uri) {
        val meta = queryMeta(uri)
        val id = UUID.randomUUID().toString()
        val p = PendingSend(id, uri, meta.first, meta.second)
        offeredSend = p
        signaling.sendJson(JSONObject().put("type", "signal").put("data", JSONObject()
            .put("kind", "file_offer").put("id", p.id).put("name", p.name).put("size", p.size)))
        callback.onState("In attesa dell'accettazione di ${p.name}…")
    }

    private fun sendFileInternal(p: PendingSend) {
        if (channel?.state() != DataChannel.State.OPEN) { pendingSend = p; return }
        executor.execute {
            try {
                context.contentResolver.openInputStream(p.uri)?.use { raw ->
                    BufferedInputStream(raw).use { input ->
                        val buffer = ByteArray(16 * 1024)
                        var sent = 0L
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            while ((channel?.bufferedAmount() ?: 0L) > 512 * 1024) Thread.sleep(10)
                            val bytes = java.nio.ByteBuffer.wrap(buffer.copyOf(n))
                            if (channel?.send(DataChannel.Buffer(bytes, true)) != true) throw IllegalStateException("DataChannel non disponibile")
                            sent += n
                            callback.onProgress(if (p.size > 0) (sent * 100.0 / p.size).roundToInt() else 0, "Invio ${p.name}")
                        }
                    }
                } ?: throw IllegalStateException("Impossibile aprire il file")
                channel?.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap("{\"kind\":\"file_end\",\"id\":\"${p.id}\"}".toByteArray()), false))
                callback.onCompleted("File inviato: ${p.name}")
            } catch (e: Exception) { callback.onError(e.message ?: "Errore durante l'invio") }
        }
    }

    fun accept(id: String) { signaling.sendJson(JSONObject().put("type", "signal").put("data", JSONObject().put("kind", "file_accept").put("id", id))) }
    fun reject(id: String) { incoming.remove(id); signaling.sendJson(JSONObject().put("type", "signal").put("data", JSONObject().put("kind", "file_reject").put("id", id))) }

    private fun handleText(text: String) {
        val json = runCatching { JSONObject(text) }.getOrNull() ?: return
        when (json.optString("kind")) {
            "file_offer" -> {
                val id = json.optString("id"); val name = json.optString("name", "file"); val size = json.optLong("size")
                incoming[id] = Incoming(name, size); callback.onIncoming(id, name, size)
            }
            "file_end" -> finishIncoming(json.optString("id"))
            "file_accept" -> {
                val id = json.optString("id")
                offeredSend?.takeIf { it.id == id }?.let { offeredSend = null; sendFileInternal(it) }
            }
            "file_reject" -> {
                if (offeredSend?.id == json.optString("id")) { offeredSend = null; callback.onState("Trasferimento rifiutato") }
            }
            "input" -> handleRemoteInput(json)
        }
    }

    private fun handleBinary(buffer: java.nio.ByteBuffer) {
        // Binary frames carry only the currently accepted file's payload.
        val id = incoming.keys.lastOrNull() ?: return
        val item = incoming[id] ?: return
        val copy = ByteArray(buffer.remaining()); buffer.get(copy); item.out.write(copy)
        callback.onProgress(if (item.size > 0) (item.out.size() * 100.0 / item.size).roundToInt() else 0, "Ricezione ${item.name}")
    }

    private fun finishIncoming(id: String) {
        val item = incoming.remove(id) ?: return
        val safe = item.name.substringAfterLast('/').substringAfterLast('\\').ifBlank { "file" }
        val file = java.io.File(context.getExternalFilesDir("received"), safe)
        file.parentFile?.mkdirs(); file.writeBytes(item.out.toByteArray())
        callback.onCompleted("Ricevuto: ${file.name}")
    }


    private fun handleRemoteInput(json: JSONObject) {
        if (!RemoteControlPreferences.enabled(context)) return
        when (json.optString("action")) {
            "request" -> callback.onRemoteControlRequest()
            "tap" -> RemoteInputService.dispatch("tap", json.optDouble("x").toFloat(), json.optDouble("y").toFloat())
            "swipe" -> RemoteInputService.dispatch("swipe", json.optDouble("x").toFloat(), json.optDouble("y").toFloat(), json.optDouble("x2").toFloat(), json.optDouble("y2").toFloat())
            "type" -> RemoteInputService.dispatch("type", text = json.optString("text"))
            "back" -> RemoteInputService.dispatch("back")
            "home" -> RemoteInputService.dispatch("home")
        }
    }

    fun sendInput(action: String, x: Float = 0f, y: Float = 0f, x2: Float = 0f, y2: Float = 0f, text: String = "") {
        if (channel?.state() != DataChannel.State.OPEN) return
        val json = JSONObject().put("kind", "input").put("action", action)
            .put("x", x).put("y", y).put("x2", x2).put("y2", y2)
        if (text.isNotEmpty()) json.put("text", text)
        channel?.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap(json.toString().toByteArray()), false))
    }

    fun requestRemoteControl() = sendInput("request")

    private fun queryMeta(uri: Uri): Pair<String, Long> {
        var name = "file"; var size = 0L
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) }
                c.getColumnIndex(android.provider.OpenableColumns.SIZE).takeIf { it >= 0 && !c.isNull(it) }?.let { size = c.getLong(it) }
            }
        }
        return name to size
    }

    fun close() {
        runCatching { screenCapturer?.stopCapture() }
        screenCapturer?.dispose(); screenCapturer = null
        videoSource?.dispose(); videoSource = null
        localVideoTrack?.dispose(); localVideoTrack = null
        eglBase?.release(); eglBase = null
        channel?.dispose(); channel = null
        peer?.close(); peer = null
        factory.dispose(); executor.shutdownNow()
    }
}

open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) = Unit
    override fun onSetSuccess() = Unit
    override fun onCreateFailure(error: String) = Unit
    override fun onSetFailure(error: String) = Unit
}
