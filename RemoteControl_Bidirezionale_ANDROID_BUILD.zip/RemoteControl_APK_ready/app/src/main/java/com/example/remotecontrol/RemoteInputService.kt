package com.example.remotecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicReference

/**
 * Optional, user-enabled Android AccessibilityService used only for consented
 * remote input. Android itself controls activation of the service.
 */
class RemoteInputService : AccessibilityService() {
    companion object {
        private val instance = AtomicReference<RemoteInputService?>(null)

        fun isRunning(): Boolean = instance.get() != null

        fun dispatch(command: String, x: Float = 0f, y: Float = 0f,
                     x2: Float = 0f, y2: Float = 0f, text: String? = null) {
            val service = instance.get() ?: return
            if (!RemoteControlPreferences.enabled(service)) return
            when (command) {
                "tap" -> service.gesture(x, y, x, y, 80)
                "swipe" -> service.gesture(x, y, x2, y2, 350)
                "type" -> service.typeText(text ?: return)
                "back" -> service.performGlobalAction(GLOBAL_ACTION_BACK)
                "home" -> service.performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance.set(this)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance.compareAndSet(this, null)
        super.onDestroy()
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                .build(), null, null
        )
    }

    private fun typeText(value: String) {
        val root = rootInActiveWindow ?: return
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (!node.isEditable) return
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}

object RemoteControlPreferences {
    private const val PREFS = "remote_control"
    private const val ENABLED = "enabled"

    fun enabled(context: android.content.Context): Boolean =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getBoolean(ENABLED, false)

    fun setEnabled(context: android.content.Context, value: Boolean) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putBoolean(ENABLED, value).apply()
    }
}
