# Remote Control Bidirezionale

Progetto per assistenza remota tra dispositivi autorizzati.

## Modulo attuale
- Pairing locale con codice a 6 cifre.
- Sessione Android con MediaProjection e notifica persistente.
- Client di segnalazione WebSocket Android/iOS.
- Server di segnalazione Node.js che abbina al massimo due dispositivi per codice e inoltra solo messaggi WebRTC.
- Il server non trasporta video/audio né contenuti dei file: inoltra solo messaggi di segnalazione WebRTC.

## Avvio del server
```bash
cd signaling-server
npm install
npm start
```
Il server ascolta su `ws://0.0.0.0:8787` (porta configurabile con `PORT`).

## Configurazione client
Sostituire nel codice l'URL di sviluppo con l'URL `wss://` del proprio server. Su iOS, `127.0.0.1` indica il dispositivo iOS stesso, non un computer remoto.

## Prossimo modulo
Collegamento del signaling a PeerConnection/WebRTC e trasformazione della superficie MediaProjection in una traccia video, con consenso esplicito e indicatori visibili.

## Limiti
Non include installazione nascosta, bypass dei permessi, disattivazione delle protezioni, sorveglianza occulta o controllo senza consenso.

## Scambio file via WebRTC DataChannel
- Android: pulsante **Invia file** tramite il selettore documenti di sistema.
- iOS: pulsante **Invia file** tramite `fileImporter`.
- Il destinatario riceve un'offerta con nome e dimensione e deve accettare o rifiutare.
- I byte del file passano sul WebRTC DataChannel; il WebSocket trasporta soltanto la segnalazione.
- Android salva i file ricevuti nell'area privata dell'app (`received/`); iOS nella Documents directory.
- Il server non riceve né archivia i contenuti dei file.
